# @agrismartchain/noki-shared-contracts

TypeScript package holding NOKI SERVICE's generated OpenAPI contracts and a thin, purely technical Fetch-based HTTP client foundation, shared across NOKI SERVICE consumer applications.

## Status

**0.46.0 local contract gate — DELIVERY routing vehicle mode.** The repository keeps every previously delivered seller self-service, internal, and driver-audience surface, and the stateless driver navigation contract (`POST /v1/driver/navigation/route`) now accepts an optional `vehicleMode` (`'CAR' | 'MOTORCYCLE'`) so `DELIVERY` requests route on the driver's actual vehicle instead of an unconditional `motorcycle` default, generated from `noki-api` commit `31858ce39350c774de6f42d1e62edebac88b16be`. No package publication was performed.

- Final handoff: [`docs/handoff/final-handoff.md`](docs/handoff/final-handoff.md)
- Final review: [`docs/reports/final-review.md`](docs/reports/final-review.md)
- Consumer guides:
  - [`docs/guides/nextjs-consumption.md`](docs/guides/nextjs-consumption.md)
  - [`docs/guides/n8n-contract-consumption.md`](docs/guides/n8n-contract-consumption.md)
- Flutter ADR: [`docs/adr/0003-flutter-openapi-client-strategy.md`](docs/adr/0003-flutter-openapi-client-strategy.md)

Consumer repositories are not modified by this repository's publication phase. Publication is allowed only through `.github/workflows/publish-package.yml` on `main`, with explicit `version` and `confirmation` inputs and GitHub Packages npm registry authentication via `GITHUB_TOKEN`.

Phase 8 remains in force — CI integration, contract gate, release readiness, and a publication guard are still the active automation baseline. See [`docs/architecture/continuous-integration.md`](docs/architecture/continuous-integration.md) and [`docs/policies/publication.md`](docs/policies/publication.md).

Phase 7 (contract compatibility detection and SemVer versioning policy) remains in force — see [`docs/architecture/contract-compatibility.md`](docs/architecture/contract-compatibility.md) and [`docs/policies/versioning.md`](docs/policies/versioning.md). Phase 6 (reproducibility, determinism, and package verification) also remains in force — see [`docs/architecture/package-verification.md`](docs/architecture/package-verification.md).

- Package name: `@agrismartchain/noki-shared-contracts`
- Current version: `0.46.0`
- Publish registry: `https://npm.pkg.github.com`
- Publication path: `workflow_dispatch` only. See [Publication warning](#publication-warning).

## Source contract

- Owned by `noki-api`, generated from its OpenAPI export.
- Backend commit: `31858ce39350c774de6f42d1e62edebac88b16be`
- OpenAPI checksum (SHA-256): `0e83404574f8be35eba483f76ee8ddebff46f05059ba79e614af4b95354d8578`
- Full comparison evidence: [`docs/reports/phase-1-generator-comparison.md`](docs/reports/phase-1-generator-comparison.md)
- Decision record: [`docs/adr/0001-openapi-generation-strategy.md`](docs/adr/0001-openapi-generation-strategy.md)
- Provenance details: [`docs/architecture/contract-provenance.md`](docs/architecture/contract-provenance.md)

## Admin authorization capabilities

This sync adds `GET /v1/auth/capabilities` and the related `AuthCapabilitiesResponseDto`, membership, role, and country-scope schemas. Admin frontends can now render navigation and executive surfaces from backend-derived effective permissions instead of probing domain endpoints.

## Admin analytics overview

This sync adds `GET /v1/analytics/admin-overview` and structured `AdminOverview*Dto` schemas for executive KPIs, backlog, anomalies, finance totals, and explicit automation/AI configuration status.

## Admin settings management

This sync adds the additive admin settings surface: `GET /v1/admin/settings/overview`, platform settings, feature flags, templates, limit policies, and SLA policies, with controlled PATCH operations and structured `AdminSettings*`, `AdminPlatformSetting*`, `AdminFeatureFlag*`, `AdminTemplate*`, `AdminLimitPolicy*`, and `AdminSlaPolicy*` schemas.

## Seller payment methods and subscription

This sync adds seller-scoped payment-method setup/replacement/revocation/default-selection contracts, subscription plan discovery, subscription lifecycle, usage, invoice download, payment-request creation, admin subscription-plan governance, and finance settlement/failure endpoints. The legacy `POST /v1/seller/finance/payment-methods` contract remains available and deprecated for 0.34.0 clients; new Seller Portal flows use `POST /v1/seller/finance/payment-methods/from-setup-intent` after creating a short-lived setup intent. The generated schemas intentionally expose setup tokens and masked destinations only where needed for the governed setup flow; raw banking or mobile-money values remain outside read responses.

## Typed Commerce shipping contracts

This sync types `GET /v1/admin/commerce/shipping` with `CommerceShippingListResponseDto` and `CommerceShippingListItemDto`. Consumers can use optional UUID query filters `shipmentId` and `fulfillmentTaskId`, and response items expose named shipping fields including `fulfillmentTaskId`, `orderNumber`, `shipmentStatus`, `qcStatus`, `codAmount`, `driverName`, `sellerName`, `warehouseName`, `destination`, `lastLatitude`, `lastLongitude`, and `lastPositionAt` without local casts or competing local types.

## Delivery v1 capabilities

This sync adds the following backend capabilities to the canonical contract, all additive and backward compatible (10 new paths, `GET /v1/orders` added to the existing `/v1/orders` path, 15 new schemas; see [`docs/architecture/contract-provenance.md`](docs/architecture/contract-provenance.md) for the full compatibility record):

- **Hotline order readiness** — `HOTLINE` is a valid `sourceType` value on `OrderListItemResponseDto`. `POST /v1/orders` (order creation) is unchanged.
- **Order list/search** — `GET /v1/orders` with pagination (`page`, `pageSize`) and filters (`search`, `sourceType`, `status`, `customerPhone`, `externalReference`, `createdFrom`, `createdTo`, and more).
- **Driver-owned delivery missions** — `GET /v1/delivery/missions` and `GET /v1/delivery/missions/{id}` return only the authenticated driver's own missions (`DriverMissionResponseDto`, `DriverMissionListResponseDto`, `DriverMissionLineResponseDto`), bearer-authenticated.
- **Secure delivery QR** — issue, rotate, revoke, and scan endpoints (`POST /v1/delivery/shipments/{id}/qr/{issue,rotate,revoke}`, `POST /v1/delivery/missions/scan-qr`). The opaque QR token is returned once at issuance for printing; the backend stores only its hash, and no response schema in this contract exposes that hash.
- **Secure delivery handoff OTP** — request and verify endpoints (`POST /v1/delivery/missions/{id}/handoff-otp/{request,verify}`). The customer-facing 6-digit code is submitted by the caller on verify (`VerifyDeliveryHandoffOtpDto.code`); no response schema echoes back a raw code or a hash of it.
- **Delivery evidence and secure completion** — `POST /v1/delivery/missions/{id}/complete` (`CompleteDriverMissionDto` → `DriverMissionCompletionResponseDto`) references an `evidenceId`, never a raw secret.
- **GPS minimum** — `latitude`, `longitude`, and `accuracyMeters` (bounded to valid ranges) are attached to mission completion and incident events.
- **Delivery incidents** — `POST /v1/delivery/missions/{id}/incidents` to create (`CreateDeliveryIncidentDto`) and read (`DeliveryIncidentResponseDto`) incidents with `DELAY` / `VEHICLE_ISSUE` / `SAFETY` / `OTHER` types.

QR issuance/rotation/revocation and OTP challenge/verification logic is entirely backend-owned: this package only types the request/response shapes above. Do not reproduce token or OTP validation logic in a frontend consumer, and do not assume any ownership or permission check beyond what the backend enforces — the backend remains the sole source of truth for both.

## Seller Inventory and Inbound Shipments

This sync adds the seller-scoped Seller Inventory module (`GET /v1/seller/inventory/warehouses`, stock list/summary/detail/movements/alerts, and CSV export — 10 paths) and the seller-scoped Seller Inbound Shipments module (`/v1/seller/inbound-shipments/...`: create/update/submit/cancel of DRAFT shipments, shipment lines, read-only receipts, documents via an upload-intent flow, CSV/XLSX import of lines, and CSV export — 20 paths). Both modules are scoped to the caller's `X-Seller-Profile-Id` context. Purely additive: no existing endpoint, schema, enum, or required field changed.

## Seller Analytics

Four seller-scoped, read-only analytics endpoints, all reusing the caller's `X-Seller-Profile-Id` context and the existing Order/Confirmation/Delivery/Finance/Inventory/Catalog/Affiliate domains (no second engine):

- `GET /v1/seller/analytics/dashboard` — a single combined summary across all seven domains, gated on `seller.analytics.summary.read`. `currencyCode` narrows every money-bearing aggregate to the requested currency; count-only metrics stay unfiltered.
- `GET /v1/seller/analytics/trends` — a time-bucketed series for one metric at a time (13 metrics: orders, orderAmount, confirmations, deliveries, returns, fees, expenses, bonuses, netAmount, availableStock, inbound, affiliateOrders, affiliateOrderAmount). Granularity is `hour` | `day` | `week` | `month`; `hour` is only accepted for a period bounded to at most 7 days. Buckets are calendar-aligned in the resolved timezone, chronologically ordered, capped at a maximum point count, and empty buckets are returned explicitly (`missingData: true`) rather than omitted.
- `GET /v1/seller/analytics/breakdowns` — a paginated breakdown of one metric by one whitelisted dimension (country, currency, product, offer, orderSource, orderStatus, confirmationOutcome, deliveryOutcome, warehouse, affiliate), each with its own metric compatibility matrix; incompatible combinations are rejected with `422`.
- `POST /v1/seller/analytics/exports`, `GET /v1/seller/analytics/exports/{exportId}`, `GET /v1/seller/analytics/exports/{exportId}/download` — CSV-only exports (DASHBOARD_SUMMARY, ORDERS, CONFIRMATION, DELIVERY, CATALOG, INVENTORY, FINANCE, AFFILIATE, TRENDS, BREAKDOWN types), gated on `seller.analytics.export` plus the read permission of the exported domain, with a 15-minute TTL, an `Idempotency-Key` requirement, and a 404 (not 403) response for a foreign export id.

Every money-bearing field across these four endpoints stays grouped by currency and is never summed across currencies; an ambiguous multi-currency monetary series (no `currencyCode` given, more than one currency present) returns an honest `unavailableReason` rather than fabricating a cross-currency total.

## Driver navigation route vehicle mode

`POST /v1/driver/navigation/route`'s `ComputeDriverRouteRequestDto` gains an optional `vehicleMode` field (`'CAR' | 'MOTORCYCLE'`), reusing the vehicle-mode vocabulary already used by Mobility's `requiredVehicleType` and `DriverContextVehicleSummaryDto.type`. `TAXI` and `TAXI_MOTO` resolution is unchanged. For `DELIVERY`, the backend now selects the routing costing profile from `vehicleMode` (`MOTORCYCLE` -> `motorcycle`, `CAR` -> `auto`) instead of the previous unconditional `motorcycle` default; when `vehicleMode` is absent, the documented conservative fallback is now `auto`, not `motorcycle`. Purely additive and backward compatible: omitting `vehicleMode` keeps existing callers working exactly as before this change was made.

## Canonical contract copy

- OpenAPI JSON: [`spec/openapi/noki-api.openapi.json`](spec/openapi/noki-api.openapi.json) — byte-for-byte copy of the backend source, never reformatted.
- Checksum: [`spec/checksums/noki-api.openapi.sha256`](spec/checksums/noki-api.openapi.sha256)
- Provenance manifest: [`spec/contract-manifest.json`](spec/contract-manifest.json)

## Tarball contract artifacts

The packed npm archive now distributes these three canonical contract files exactly as tracked in `spec/`:

- `package/spec/openapi/noki-api.openapi.json`
- `package/spec/checksums/noki-api.openapi.sha256`
- `package/spec/contract-manifest.json`

The checksum intentionally remains under `spec/checksums/`. The package is publishable only through the gated GitHub Packages workflow, and each published version must never be overwritten once published.

### Synchronizing

```bash
pnpm contract:sync                # uses the sibling ../noki-api by default
pnpm contract:sync -- /path/to/noki-api   # or an explicit backend path
```

`contract:sync` reads the backend repository (read-only) and refuses to run against any commit other than the one currently locked in `scripts/sync-openapi.mjs`. It never writes to the backend and never runs implicitly during install or build.

### Verifying

```bash
pnpm contract:verify
```

`contract:verify` is fully autonomous: it checks only files already committed in this repository (canonical OpenAPI JSON, checksum, manifest) and never requires `noki-api` to be present. It is included in `pnpm check`.

## Generated TypeScript types

- Generated file: [`src/generated/schema.ts`](src/generated/schema.ts) — produced exclusively from [`spec/openapi/noki-api.openapi.json`](spec/openapi/noki-api.openapi.json) by `openapi-typescript`.
- **Never hand-edit this file.** It starts with an `AUTO-GENERATED FILE. DO NOT EDIT.` banner and is fully regenerable from the canonical contract alone.
- Generation is fully autonomous: it never reads or requires `noki-api` to be present, and never modifies any file other than `src/generated/schema.ts`.
- No HTTP client, no Zod validation, no mocks, and no runtime logic are generated — types only. See [`docs/architecture/schema-generation.md`](docs/architecture/schema-generation.md) for the exact command and options.

### Generating

```bash
pnpm generate
```

Regenerates `src/generated/schema.ts` from the canonical OpenAPI contract. This is never run implicitly during `install`, `postinstall`, `prepare`, or `build` — it is always an explicit, separate action.

### Checking

```bash
pnpm generate:check
```

Regenerates in memory and compares against the committed `src/generated/schema.ts` without writing anything. Fails if the file is missing, was hand-edited, or is stale relative to the canonical contract. It is included in `pnpm check`.

## Using the client

```ts
import { createNokiClient } from '@agrismartchain/noki-shared-contracts';

const client = createNokiClient({
  baseUrl: 'https://api.example.com',
});

const result = await client.GET('/v1/health/live');
```

`createNokiClient()` returns exactly what `openapi-fetch`'s `createClient<paths>()` returns — a typed client, with no business logic added. See [`docs/architecture/runtime-client.md`](docs/architecture/runtime-client.md) for the full signature, the `/v1` `baseUrl` behavior, and what the helper deliberately does not do (no session handling, no token storage, no authorization logic).

### Public entry points

```ts
// Root: client helper + generated types together
import { createNokiClient, type paths, type components } from '@agrismartchain/noki-shared-contracts';

// Client only
import { createNokiClient } from '@agrismartchain/noki-shared-contracts/client';

// Types only
import type { paths } from '@agrismartchain/noki-shared-contracts/schema';
```

Contract file exports:

```ts
const openApiUrl = import.meta.resolve(
  '@agrismartchain/noki-shared-contracts/openapi',
);

const metadataUrl = import.meta.resolve(
  '@agrismartchain/noki-shared-contracts/metadata',
);
```

These resolve to the packed JSON files, which consumers can then read with `fs` after converting the returned URLs to paths. `src/generated/schema.ts` and `src/runtime/create-noki-client.ts` remain internal; the full public export surface is `.`, `./client`, `./schema`, `./openapi`, and `./metadata`.

## Verifying the package

```bash
pnpm package:verify
```

Packs a real npm archive into a temporary directory, inspects its file list against an allowlist (`dist/`, `package.json`, `README.md`, `spec/openapi/noki-api.openapi.json`, `spec/checksums/noki-api.openapi.sha256`, `spec/contract-manifest.json` only), installs it into a throwaway consumer project, validates byte-for-byte preservation of the three contract artifacts, resolves `./openapi` and `./metadata` from the installed package, and executes the client with a simulated `fetch` — all without any network access or access to `noki-api`. It is included in `pnpm check`, after `build`. See [`docs/architecture/package-verification.md`](docs/architecture/package-verification.md) for the full methodology, including schema/build/archive determinism proofs and the reproducibility test from a clean worktree with no sibling `noki-api`.

## Generator and client choice

- Type generation: [`openapi-typescript`](https://openapi-ts.dev/) `7.13.0`
- HTTP client runtime: [`openapi-fetch`](https://openapi-ts.dev/openapi-fetch/) `0.17.0`

Both were selected in Phase 1 over Kubb and Orval for matching this project's mandated `{ baseUrl, fetch?, headers? }` runtime contract natively, with the smallest generated surface and fewest runtime dependencies. See the ADR linked above for full reasoning.

## Contract compatibility and versioning (Phase 7)

```bash
pnpm setup:oasdiff                # one-time: vendor the pinned, checksum-verified oasdiff binary
pnpm contract:compatibility:self  # self-comparison of the canonical spec (always "unchanged")
pnpm version:policy:self          # self-comparison of package.json against itself (always "ok")
```

`scripts/check-contract-compatibility.mjs` classifies two OpenAPI revisions (from files or a local Git ref) as `unchanged`, `compatible`, `breaking`, or `invalid`, using `oasdiff` v1.23.0. `scripts/check-version-policy.mjs` then enforces this project's SemVer bump policy against that classification: mandatory `minor` for both breaking and compatible changes while the package is `0.x`, `patch` for fixes, and the standard major/minor/patch mapping once an explicitly authorized move to `1.0.0` happens (not yet granted). See [`docs/architecture/contract-compatibility.md`](docs/architecture/contract-compatibility.md) and [`docs/policies/versioning.md`](docs/policies/versioning.md) for full usage, and [`docs/adr/0002-contract-compatibility-and-versioning.md`](docs/adr/0002-contract-compatibility-and-versioning.md) for the tool comparison and decision record.

Neither script requires or reads `noki-api`. Neither modifies `package.json`, the canonical spec, or the generated schema.

## Continuous integration (Phase 8)

```bash
pnpm workflows:verify    # static structural checks of .github/workflows/*.yml
pnpm publication:guard   # static guard against accidental publication
```

`.github/workflows/ci.yml` runs on every pull request and push to `main`: install, `setup:oasdiff`, `workflows:verify`, `pnpm check`, and — on pull requests only — `scripts/ci-contract-gate.mjs --base-ref <PR base sha>`. `.github/workflows/release-readiness.yml` is a `workflow_dispatch`-only dry run. `.github/workflows/publish-package.yml` is the only workflow allowed to use `packages: write` or run `npm publish`; it checks inputs, verifies the version is absent from the registry, packs and inspects the archive, publishes to GitHub Packages, then installs and type-smoke-tests the published package. See [`docs/architecture/continuous-integration.md`](docs/architecture/continuous-integration.md) and [`docs/policies/publication.md`](docs/policies/publication.md).

## Requirements

- WSL/Linux with `/bin/bash`. PowerShell is not supported and must not be used for any command in this repository.
- Node.js `>=24.0.0 <25` (see `.nvmrc` / `.node-version`)
- pnpm `>=10.23.0`

## Local installation

```bash
cd ~/dev/noki-service/noki-shared-contracts
pnpm install
```

## Commands

```bash
pnpm lint          # ESLint, read-only, no --fix (src/generated/** excluded, never hand-fixed)
pnpm typecheck     # tsc --noEmit, strict (includes src/generated/schema.ts and the consumer-compilation fixture)
pnpm test          # vitest run (contract provenance, generated schema, runtime client, public exports, package structure/exports, determinism)
pnpm build         # tsc -p tsconfig.build.json -> dist/index.js, dist/client.js, dist/schema.js, dist/runtime/*, dist/generated/*
pnpm generate      # regenerate src/generated/schema.ts from the canonical contract
pnpm generate:check # verify the committed schema.ts matches generation, without writing
pnpm package:verify # pack, inspect, install, compile, and execute against a real npm archive
pnpm setup:oasdiff              # one-time: vendor the pinned, checksum-verified oasdiff binary
pnpm contract:compatibility     # classify an OpenAPI diff (pass --base-file or --base-ref)
pnpm contract:compatibility:self # self-comparison of the canonical spec (always "unchanged")
pnpm version:policy             # enforce the SemVer bump policy (pass --change-status and refs/paths)
pnpm version:policy:self        # self-comparison of package.json against itself (always "ok")
pnpm workflows:verify           # static structural checks of .github/workflows/*.yml
pnpm publication:guard          # static guard against accidental publication
pnpm check         # lint && typecheck && test && build && contract:verify && generate:check && package:verify && contract:compatibility:self && version:policy:self && workflows:verify && publication:guard
```

`pnpm install --frozen-lockfile` (instead of `pnpm install`) reproduces dependencies exactly from the committed `pnpm-lock.yaml`, without ever modifying it — the way this package should be installed on a clean machine or in an automated environment.

## Final handoff references

- Handoff summary: [`docs/handoff/final-handoff.md`](docs/handoff/final-handoff.md)
- Final review verdict: [`docs/reports/final-review.md`](docs/reports/final-review.md)
- Next.js integration guide: [`docs/guides/nextjs-consumption.md`](docs/guides/nextjs-consumption.md)
- n8n consumption guide: [`docs/guides/n8n-contract-consumption.md`](docs/guides/n8n-contract-consumption.md)
- Flutter strategy ADR: [`docs/adr/0003-flutter-openapi-client-strategy.md`](docs/adr/0003-flutter-openapi-client-strategy.md)

## Warnings

### No runtime validation

`createNokiClient()` provides compile-time type safety only. No response or request validation library (Zod or otherwise) is added — see [`docs/architecture/runtime-client.md`](docs/architecture/runtime-client.md).

### Publication warning

Do not publish locally. `@agrismartchain/noki-shared-contracts` may be published only by `.github/workflows/publish-package.yml` from `main`, with matching `version` and `confirmation=PUBLISH_<version>` inputs, using `NODE_AUTH_TOKEN: ${{ secrets.GITHUB_TOKEN }}`. Registry versions are immutable: if a version already exists or a publish partially succeeds, stop and investigate; never overwrite or republish the same version. No deployment is part of this workflow.

## Base URL behavior

`noki-api`'s corrected OpenAPI contract no longer declares `servers[0].url = "/v1"`. The typed path keys still carry `/v1/...`, and this package keeps them unchanged.

- `createNokiClient()` never rewrites the contract and never adds or removes `/v1` from the caller's `baseUrl`.
- Pass the bare origin as `baseUrl` (for example `https://api.example.com`) because the typed paths already include `/v1`.
- Passing `https://api.example.com/v1` still produces a double-prefixed request path such as `/v1/v1/...`, because the helper forwards `baseUrl` unchanged.

See [`docs/architecture/runtime-client.md`](docs/architecture/runtime-client.md) for the full behavior and tests proving it.
